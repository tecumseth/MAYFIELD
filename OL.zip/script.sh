#PBS -N ANP.exe
#PBS -l walltime=72:00:00
#PBS -l nodes=1:ppn=1
#PBS -j oe
#PBS -m abe

module load python/3.6-conda5.2
source activate mayfield
cd /users/PAS1420/osu10468/UPDATED/python/OL/
python mayfield.py > results
cp results /users/PAS1420/osu10468/UPDATED/python/OL/
source deactivate mayfield