import csv, math
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import mode

global K, Y, U, Klist
position = 'OL'
root = '/users/PAS1420/osu10468/UPDATED/python/'+position+'/'
Klist = [25,10,5,1]
Y = 3
U = 1

class player:
    def __init__(self, b):
        self.name = ''
        self.biop = list()
        self.varp = list()
        self.datp = list()
        self.years = list()
        self.segments = list()
        self.name = b[0]
        self.biop = b[1:]

    def addSeason(self, v, d):
        self.varp.append(v[2:len(v)])
        self.datp.append(d[2:len(d)])
        self.years.append(int(v[1]))

    def segmenter(self):
        for i in range(len(self.years) - Y + 1):
            if int(self.years[i + Y - 1]) == int(self.years[i]) + Y - 1:
                self.segments.append(segment(self, self.years[i], self.biop, self.varp[i:i + Y], self.datp[i:i + Y]))
        segmentslist.extend(self.segments)

class segment:
    def __init__(self, plyr, fy, b, v, d):
        self.play = plyr
        self.first = int(fy)
        self.last = int(fy) + Y
        self.bio = b
        self.var = v
        self.dat = d
        self.vector = list()
        self.vector.extend(self.bio)
        for i in range(Y):
            self.vector.extend(self.var[i])
            self.vector.extend(self.dat[i])

def isnan(item):
    return item != item

def drop(array):
    df = np.transpose(array).tolist()
    for j in reversed(range(len(df))):
        if np.nanvar(df[j])==0.0:
            df.pop(j)
    return np.transpose(df)

def reindex(somelist, element):
    try:
        return somelist.index(element)
    except ValueError:
        return -1

def stringtolist(str):
    list1 = list()
    str1 = str+';'
    while reindex(str1, ';') != -1:
        list1.append(str1[0:str1.index(';')])
        if str1.index(';')!=len(str1):
            str1 = str1[str1.index(';') + 1:]
        else:
            break
    return list1

def jaccard(stra, strb):
    return jac(stringtolist(stra),stringtolist(strb))

def jac(list1, list2):
    count = 0
    for str in list1:
        if reindex(list2, str) != -1: count += 1
    return 1.0 - 1.0 * count / (len(list1) + len(list2) - count)

def distances(vector1, vector2):
    edit = [list() for j in range(4)]
    edit[0].extend(features[vector1])
    edit[1].extend(features[vector2])
    edit[2].extend(categoricals[vector1])
    edit[3].extend(categoricals[vector2])
    qm = 0
    rm = 0
    for j in reversed(range(q)):
        if isnan(edit[0][j]) or isnan(edit[1][j]):
            qm += 1
            edit[0][j] = 0
            edit[1][j] = 0
    for j in reversed(range(r)):
        if isnan(edit[2][j]) or isnan(edit[3][j]):
            rm += 1
            edit[2].pop(j)
            edit[3].pop(j)
    return euclidean(edit[0], edit[1], covarianceF), compjaccard(edit[2],edit[3]), q+r-qm-rm

def compjaccard(vec1,vec2):
    return sum([jaccard(vec1[i],vec2[i]) for i in range(len(vec1))])

def euclidean(vec1, vec2, sig):
    return sum([math.sqrt(pow(vec1[i]-vec2[i],2.0)/sig[i]) for i in range(q)])

def similarity(qd, cd, df):
    return np.exp(-0.5*pow((qd + cd)/df,2.0))

def predict(vector):
    return np.matmul(np.power(similar[vector],2.0),np.array(futures)[compare[vector]])/sum(np.power(similar[vector],2.0)).tolist()

def loess(predictions,j):
    if isnan(sm.nonparametric.lowess(np.transpose(futures[:N])[j], predictions, frac=np.log2(N)/N, it=1, return_sorted=False)[0]):
        return predictions
    else:
        return sm.nonparametric.lowess(np.transpose(futures[:N])[j], predictions, frac=np.log2(N)/N, it=1, return_sorted=False)

#setup
global p, q, r, similar, compare, futures, features, categoricals, segmentslist, covarianceF
K = Klist[0]
segmentslist = list()
bios = list(csv.reader(open(root + position+ 'bios.csv', newline='')))
vars = list(csv.reader(open(root + position+'variates.csv', newline='')))
data = list(csv.reader(open(root + position+'data.csv', newline='')))
bcat = bios[0][1:]
vcat = vars[0][2:]
dcat = data[0][2:]
vectorcat = bcat
for i in range(Y):
    vectorcat.extend(vcat)
    vectorcat.extend(dcat)
playerslist = [player(bios[i + 2]) for i in range(len(bios) - 2)]
i = 0
for j in range(2, len(vars)):
    if vars[j][0] != playerslist[i].name:
        i += 1
    playerslist[i].addSeason(vars[j], data[j])
for p in playerslist:
    p.segmenter()
q = len(vectorcat)
p = len(dcat)
r = 0
#preprocessing
features = [seg.vector for seg in segmentslist if reindex(seg.play.years, seg.last + U) != -1]
futures = [seg.play.datp[seg.play.years.index(seg.last + U)] for seg in segmentslist if reindex(seg.play.years, seg.last + U) != -1]
names = [seg.play.name+str(seg.last+U) for seg in segmentslist if reindex(seg.play.years, seg.last + U) != -1]
N = len(features)
for i in range(N):
    for j in range(q):
        if features[i][j] =='':
            features[i][j] = np.nan
categoricals = [list() for i in features]
for j in reversed(range(q)):
    if vectorcat[j] == 'C':
        vectorcat.pop(j)
        q-=1
        r+=1
        for i in range(N):
            categoricals[i].insert(0,features[i].pop(j))
features = drop(np.array(features,dtype='float'))
futures = drop(np.array(futures,dtype='float'))
q = len(features[0])
p = len(futures[0])
# matrix estimation
covarianceF = [np.nanvar(np.transpose(features)[j]) for j in range(q)]
#similarity estimation
similar = [list() for j in range(N)]
compare = [list() for j in range(N)]
for i in range(N):
    for j in range(1,N):
        if names[i][:-4] != names[j][:-4]:
            a, b, c = distances(i, j)
            s = similarity(a,b,c)
            similar[i].append(s)
            similar[j].append(s)
            compare[j].append(i)
            compare[i].append(j)
#prediction
optim = [list() for i in Klist]
for j in range(len(Klist)):
    K = Klist[j]
    for i in range(N):
        compare[i] = np.array(compare[i])[np.argpartition(np.array(similar[i]), len(similar[i]) - K)][-K:]
        similar[i] = np.array(similar[i])[np.argpartition(np.array(similar[i]), len(similar[i]) - K)][-K:]
    predictions = np.transpose([predict(i) for i in range(N)])
    fitted = np.transpose([loess(predictions[j],j) for j in range(p)]).tolist()
    for i in range(N):
        fitted[i].insert(0,names[i])
    pd.DataFrame(fitted).to_csv(root + position + 'predict_kn' + str(K) + "_Y"+str(Y)+".csv", sep=',', index=False)